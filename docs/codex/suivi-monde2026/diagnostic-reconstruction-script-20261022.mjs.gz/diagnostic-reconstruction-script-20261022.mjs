import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createHarness,ready,chooseCampaign} from '/workspace/scratch/b8ff726dd748/deadwall/scripts/browser-qa-common142.mjs';

const repo='/workspace/scratch/b8ff726dd748/deadwall',baseline='74a62084e96dd7e78463bd4e15b9ec2897887704';
const sha=b=>createHash('sha256').update(b).digest('hex');
const sourceFile='scripts/browser-reconstruction144.mjs',source=fs.readFileSync(path.join(repo,sourceFile),'utf8');
const fixtureSource=source.slice(source.indexOf('async function reconstructionFixture(page) {'),source.indexOf('\ntry {\n'));
if(!fixtureSource.startsWith('async function reconstructionFixture(page) {')||!fixtureSource.endsWith('}\n'))throw Error('Fixture extraction failed');
const fixture=new Function('return ('+fixtureSource+')')();
const changed=execFileSync('git',['diff','--name-only',baseline,'--','index.html','src','sw.js'],{cwd:repo,encoding:'utf8'}).trim().split('\n').filter(Boolean),overrides=new Map();
for(const file of changed)try{overrides.set(file,execFileSync('git',['show',baseline+':'+file],{cwd:repo,stdio:['ignore','pipe','ignore']}));}catch{}
process.env.DEADWALL_QA_ROOT=path.join(repo,'dist');
process.env.DEADWALL_QA_OUTPUT='/tmp/deadwall-reconstruction-20261022';
process.env.CHROMIUM_EXECUTABLE_PATH='/tmp/yautja-chromium/chromium';
const h=await createHarness('reconstruction-diagnostic','Targeted reproduction of the unchanged reconstruction house fixture before any reconstruction UI check. Actual built current distribution and baseline public HTTP blob substitution; explicit legacy author fixture, RAF disabled, genuine menu and introduction controls. No full reconstruction flow, campaign, Electron or Windows qualification.');
const r=h.report;r.surface='All profiles use the explicitly requested tools=1&fixture=legacy surface, matching the CI reconstruction harness.';
r.head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();r.baseline=baseline;r.distributionRoot=process.env.DEADWALL_QA_ROOT;r.profiles=[];r.pass=false;
r.fixture={file:sourceFile,sourceSHA256:sha(source),extractedFunctionSHA256:sha(fixtureSource),extraction:'Exact unchanged reconstructionFixture function evaluated from the repository source; no fixture rewriting.'};
r.readinessObservation='A first diagnostic attempt reproduced current desktop then timed out in the original RAF-polled ready helper on mobile. This diagnostic waits for the identical startup predicate using timer polling before invoking the unchanged ready helper. Only observation scheduling differs; the fixture, road placement rules and failures are unchanged.';
r.sourceComparison=['scripts/browser-reconstruction144.mjs','scripts/browser-qa-common142.mjs','src/core.js','src/game.js','src/exploration-125.js'].map(file=>{
 const body=fs.readFileSync(path.join(repo,file)),main=execFileSync('git',['show',baseline+':'+file],{cwd:repo});const distFile=path.join(repo,'dist',file),dist=fs.existsSync(distFile)?fs.readFileSync(distFile):null;
 return{file,sourceSHA256:sha(body),baselineSHA256:sha(main),equalToBaseline:body.equals(main),distributionSHA256:dist?sha(dist):null,distributionEqualsSource:dist?body.equals(dist):null};
});
try{
 for(const ref of ['current','baseline'])for(const view of [{name:'desktop',width:1440,height:900},{name:'mobile',width:390,height:844,touch:true}]){
  const p={ref,viewport:view,requestedURL:h.base,overrides:[],pageErrors:[],consoleErrors:[],httpErrors:[]};r.profiles.push(p);
  const context=await h.browser.newContext({viewport:{width:view.width,height:view.height},isMobile:!!view.touch,hasTouch:!!view.touch,deviceScaleFactor:1,serviceWorkers:'block'}),page=await context.newPage();page.setDefaultTimeout(30000);
  page.on('pageerror',e=>p.pageErrors.push(e.message));page.on('console',e=>{if(e.type()==='error')p.consoleErrors.push(e.text());});page.on('response',e=>{if(e.status()>=400)p.httpErrors.push({status:e.status(),url:e.url()});});
  if(ref==='baseline')await page.route('**/*',route=>{const u=new URL(route.request().url()),file=u.pathname==='/'?'index.html':u.pathname.slice(1),body=overrides.get(file);if(!body)return route.continue();p.overrides.push({file,commit:baseline,sha256:sha(body)});return route.fulfill({status:200,body,contentType:file.endsWith('.html')?'text/html; charset=utf-8':'text/javascript; charset=utf-8'});});
  try{
   await page.addInitScript(()=>{globalThis.requestAnimationFrame=()=>0;globalThis.cancelAnimationFrame=()=>{};});
   console.log(JSON.stringify({ref,viewport:view.name,stage:'load'}));
   await page.goto(h.base,{waitUntil:'networkidle',timeout:120000});
   await page.waitForFunction(()=>globalThis.DEADWALL?.campaignIntro132&&DEADWALL.frontierUI&&DEADWALL.fieldAtlasUI&&!document.getElementById('newGameButton').disabled,null,{polling:50,timeout:120000});
   await ready(page);await chooseCampaign(page);
   for(let i=0;i<4;i++)if(view.touch)await page.locator('#campaignIntro132Next').tap();else await page.locator('#campaignIntro132Next').click();
   await page.waitForFunction(()=>!DEADWALL.activeOverlay&&!DEADWALL.paused);
   p.before=await page.evaluate(()=>({seed:DEADWALL.world.seed,difficulty:DEADWALL.difficulty.id,scenario:DEADWALL.scenarioId,generation:DEADWALL.frontier.snapshot().generation,cityGeometry202:DEADWALL.world.cityGeometry202,layoutRevision:DEADWALL.exploration125.layoutRevision,paused:DEADWALL.paused,overlay:DEADWALL.activeOverlay?.id||null,buildings:DEADWALL.world.buildings.size,inspection:typeof DeadwallCodexInspection2026,inspectionPanels:document.querySelectorAll('[data-codex-inspection2026]').length}));
   try{p.fixtureResult=await fixture(page);p.fixtureRefused=false;}catch(error){p.fixtureRefused=true;p.fixtureError=error.message;}
   p.observation=await page.evaluate(()=>{
    const g=DEADWALL,C=DeadwallCore,E=DeadwallExploration125,plan=g.exploration125.plan,b=new(g.core().constructor)(g.nextId-1,'house',74,70,0,1),body=E.buildingFootprint(C.BUILDINGS.house,b.gx,b.gy,b.rotation,C.TILE),clearance=C.CityRoadRules202.clearance;
    const roads=[...plan.roads,...(plan.settlements||[]).flatMap(s=>[s.street,s.connector].filter(Boolean))];
    return{seed:g.world.seed,scenario:g.scenarioId,difficulty:g.difficulty.id,generation:g.frontier.snapshot().generation,layoutRevision:plan.layoutRevision,cityGeometry202:g.world.cityGeometry202,fixture:{type:b.type,gx:b.gx,gy:b.gy,rotation:b.rotation,size:C.BUILDINGS.house.size,footprint:body,clearance},placement:g.world.placement(C.BUILDINGS.house,b.gx,b.gy,b.rotation),naturalRoadOverlap:E.roadFootprint202(plan,body,clearance),naturalRoadOverlapWithoutClearance:E.roadFootprint202(plan,body,0),financedRoadOverlap:g.infrastructure.roadFootprint202(body,clearance),obstacleOverlap:E.obstacleFootprint202(plan,body),intersectingRoads:roads.filter(road=>E.roadFootprint202({roads:[road],settlements:[]},body,clearance)),after:{buildings:g.world.buildings.size,units:g.units.length,zombies:g.zombies.length,resources:{...g.resources},nonexhaustedNodes:g.world.nodes.filter(n=>n.amount>0||!n.depleted).length}};
   });
   p.diagnosticComplete=true;
   console.log(JSON.stringify({ref,viewport:view.name,before:p.before,fixtureRefused:p.fixtureRefused,fixtureError:p.fixtureError,observation:p.observation,errors:p.pageErrors.length+p.consoleErrors.length+p.httpErrors.length}));
  }catch(e){p.diagnosticComplete=false;p.diagnosticFailure=e.stack;throw e;}
  finally{await context.close();}
 }
 r.pass=r.profiles.length===4&&r.profiles.every(p=>p.diagnosticComplete);
 r.meaningOfPass='Diagnostic completed; native fixture refusals are not converted into test successes.';
}finally{await h.finish();await h.close();}
