from pathlib import Path
import io, json, hashlib, gzip, tarfile

root = Path('/workspace/scratch/b8ff726dd748/deadwall')
out = Path('/tmp/deadwall-defense148')
report_path = out/'browser/defenses-2026-10-22T11_06_41_004Z/report.json'
report = json.loads(report_path.read_text())
summary = json.loads((out/'summary.json').read_text())
summary['status'] = 'proposal-validated-not-applied' if report.get('pass') else 'proposal-browser-validation-incomplete-not-applied'
summary['validation']['browserThreeProfiles'] = {
    'status': 'pass' if report.get('pass') else ('incomplete-runtime-crash' if any('Target crashed' in p.get('failure', '') for p in report['profiles']) else 'fail'),
    'report': str(report_path.relative_to(out)),
    'log': 'browser.log', 'surface': report['surface'], 'url': report['base'],
    'started': report['started'], 'completed': report['completed'],
    'browserVersion': report['browserVersion'],
    'profiles': [{'name': p.get('name', p.get('viewport', {}).get('name')), 'pass': p.get('pass'),
                  'nativeChecks': len(p.get('native', {}).get('checks', [])),
                  'fixtureChecks': len(p.get('fixtureChecks', [])),
                  'failure': p.get('failure'),
                  'withdrawalAssertion': [c for c in p.get('fixtureChecks', []) if c.get('name') == 'A physically completed workshop gives no remote withdrawal from the depot'],
                  'errorCounts': {key: len(p.get(key, [])) for key in ['pageErrors', 'consoleErrors', 'httpErrors', 'requestFailures']}}
                 for p in report['profiles']]
}
# The runner is an exact copy except for the two imports explicitly needed to
# execute the unchanged scenario with the temporary module from /tmp.
original = (root/'scripts/browser-defenses148.mjs').read_text()
runner = (out/'browser-defenses148.mjs').read_text()
expected = original.replace("from './browser-qa-common144.mjs'", "from '/workspace/scratch/b8ff726dd748/deadwall/scripts/browser-qa-common144.mjs'").replace("from './browser-defenses-fixtures148.mjs'", "from '/tmp/deadwall-defense148/fixtures-corrected.mjs'")
assert runner == expected
summary['validation']['runnerOnlyImportPathsChanged'] = True
summary['validation']['runnerAssertionsAndProfilesUnchanged'] = True
proposed_test = (out/'defenses-qa148.proposed.test.cjs').read_text()
for variant in ['corrected', 'current']:
    expected_test = proposed_test.replace("require('../src/core.js')", "require('/workspace/scratch/b8ff726dd748/deadwall/src/core.js')").replace("require('../scripts/qa-startup134.cjs')", "require('/workspace/scratch/b8ff726dd748/deadwall/scripts/qa-startup134.cjs')").replace("import('../scripts/browser-defenses-fixtures148.mjs')", "import('/tmp/deadwall-defense148/fixtures-"+variant+".mjs')")
    assert (out/('defenses-qa148.'+variant+'.test.cjs')).read_text() == expected_test
summary['validation']['nativeExecutionCopiesOnlyImportPathsChanged'] = True

files = ['fixtures-main.mjs', 'fixtures-current.mjs', 'fixtures-corrected.mjs',
         'browser-defenses148.mjs', 'defenses-qa148.proposed.test.cjs',
         'defenses-qa148.corrected.test.cjs', 'defenses-qa148.current.test.cjs',
         'probe-access.mjs', 'probe-access.json', 'probe-corrected.mjs',
         'probe-corrected.json', 'fix.patch', 'native-current.log',
         'native-corrected.log', 'browser.log', 'provenance.json', 'runtime-observation.json', 'process-check.json', 'resume-commands.md', 'package-evidence.py',
         str(report_path.relative_to(out))]
manifest = []
for name in files:
    data = (out/name).read_bytes()
    manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
summary['artifacts'] = manifest
summary['artifactNotes'] = [
    'All paths in artifacts are relative to the deterministic archive root.',
    'Browser screenshots listed in the raw report remain temporary execution outputs and are not included in this compact archive.',
    'Absolute paths in diagnostic scripts are execution provenance, not portable tooling.',
    'No post-execution corrections were made to the raw browser report or the tested sources.'
]
(out/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
archive_dir = out/'archive'; archive_dir.mkdir(exist_ok=True)
archive_summary = archive_dir/'diagnostic-defenses-20261022.json'
archive_detail = archive_dir/'diagnostic-defenses-20261022.md'
archive_name = 'diagnostic-defenses-artefacts-20261022.tar.gz'
archive_path = archive_dir/archive_name
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
    for name in sorted(files):
        data = (out/name).read_bytes(); item = tarfile.TarInfo(name)
        item.size = len(data); item.mtime = 0; item.mode = 0o644
        item.uid = item.gid = 0; item.uname = item.gname = ''
        tar.addfile(item, io.BytesIO(data))
raw = buffer.getvalue()
with archive_path.open('wb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        compressed.write(raw)
compressed = archive_path.read_bytes()
assert gzip.decompress(compressed) == raw
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as tar:
    for entry in manifest:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
archive_record = {'path': archive_name, 'format': 'tar+gzip', 'deterministicGzipMtime': 0,
                  'deterministicTarMtime': 0, 'bytes': len(compressed),
                  'sha256': hashlib.sha256(compressed).hexdigest(),
                  'rawTarBytes': len(raw), 'rawTarSha256': hashlib.sha256(raw).hexdigest()}
summary['archive'] = archive_record
archive_summary.write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
detail = (out/'diagnostic.md').read_text()
summary_line = '\n'.join('- '+str(p['name'])+': '+('réussi' if p['pass'] else 'incomplet, arrêt par erreur')+', '+str(p['nativeChecks'])+' contrôles natifs et '+str(p['fixtureChecks'])+' contrôles de scène.' for p in summary['validation']['browserThreeProfiles']['profiles'])
detail += '\n## Résultat final du navigateur\n\n'+summary_line+'\n\nVersion Chromium : `'+report['browserVersion']+'`. Surface : `'+report['base']+'`. Aucun rejeu Windows/Electron. Le rapport brut est conservé sans modification.\n\n## Archive et intégrité\n\n`'+archive_name+'` contient les sources exactes, les deux probes, le patch non appliqué, les journaux natifs et le rapport navigateur brut. Les chemins des artefacts et leurs SHA-256 sont dans `diagnostic-defenses-20261022.json`. Gzip mtime 0, nom de fichier d’en-tête vide ; entrées tar mtime/uid/gid 0, mode 0644. Décompression et chaque empreinte sont vérifiées après écriture. Les captures mentionnées par le rapport brut restent des sorties temporaires et ne sont pas incluses dans cette archive compacte.\n\nSHA-256 archive compressée : `'+archive_record['sha256']+'`. SHA-256 tar brut : `'+archive_record['rawTarSha256']+'`.\n'
archive_detail.write_text(detail)
print(json.dumps({'summary': str(archive_summary), 'detail': str(archive_detail), 'archive': archive_record}, indent=2))
