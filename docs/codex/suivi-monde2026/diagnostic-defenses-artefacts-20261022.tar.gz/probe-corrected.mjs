import {createRequire} from 'node:module';
import fs from 'node:fs';
const require=createRequire('/workspace/scratch/b8ff726dd748/deadwall/package.json');
const {bootDocument134}=require('./scripts/qa-startup134.cjs');
const C=require('./src/core.js');
const results=[];
for(const name of ['main','current','corrected']){
 const F=await import('./fixtures-'+name+'.mjs'),{g}=bootDocument134();
 g.startNew('standard','903148');g.campaignIntro132.skip();g.togglePause(true);
 const before=g.serialize(),camp=F.defenseCampFixture();
 const observations=[];
 function observe(label){
  const service=F.defenseServiceFixture({type:'workshop'}),workshop=g.world.buildings.get(service.support),targets=[...g.world.buildings.values()].filter(b=>b.completed&&!b.dead&&(b.type==='core'||b.type==='warehouse'||b.def.storageDepot));
  const distance=b=>Math.hypot(g.player.x-Math.max(b.left,Math.min(b.right,g.player.x)),g.player.y-Math.max(b.top,Math.min(b.bottom,g.player.y)));
  observations.push({label,point:service.player,workshop:{id:workshop.id,gx:workshop.gx,gy:workshop.gy,left:workshop.left,top:workshop.top,right:workshop.right,bottom:workshop.bottom},homeReach:C.Arsenal134Rules.homeReach,atHome:g.arsenal134.view().atHome,craft:g.arsenal134.preview('craft','assemblyHammer'),targets:targets.map(b=>({id:b.id,type:b.type,body:{left:b.left,top:b.top,right:b.right,bottom:b.bottom},distance:distance(b),canWork:g.workerCanWorkAt(g.player,b,C.Arsenal134Rules.homeReach)}))});
 }
 observe('from-start');
 F.defenseServiceFixture({type:'core'});g.showCommand(true);
 const plan=F.defensePlanSiteFixture('maintenanceRedoubt');g.showCommand(false);observe('from-maintenance-plan-site');
 results.push({name,camp,plan,observations,nodesPreserved:JSON.stringify(g.serialize().nodes)===JSON.stringify(before.nodes),rngPreserved:g.random.state===before.randomState});
 console.log(JSON.stringify(results.at(-1)));
}
fs.writeFileSync('/tmp/deadwall-defense148/probe-corrected.json',JSON.stringify(results,null,2)+'\n');
