# Reprise après libération de la mémoire et application approuvée

Ces commandes sont préparées pour cet environnement précis. Elles n’ont pas été exécutées. Le produit et le runner restent ceux du dépôt ; seule la fixture approuvée doit avoir été appliquée avec les empreintes annoncées. Exécuter les profils séquentiellement, après la fin de la vérification globale. Le filtre est une option existante du runner ; il ne retire aucune étape du profil choisi.

```bash
cd /workspace/scratch/b8ff726dd748/deadwall
CHROMIUM_EXECUTABLE_PATH=/tmp/yautja-chromium/chromium DEADWALL_QA_ROOT=/workspace/scratch/b8ff726dd748/deadwall/dist DEADWALL_QA_OUTPUT=/tmp/deadwall-defense148/final DEADWALL_QA_PROFILES=desktop node scripts/browser-defenses148.mjs
CHROMIUM_EXECUTABLE_PATH=/tmp/yautja-chromium/chromium DEADWALL_QA_ROOT=/workspace/scratch/b8ff726dd748/deadwall/dist DEADWALL_QA_OUTPUT=/tmp/deadwall-defense148/final DEADWALL_QA_PROFILES=mobile node scripts/browser-defenses148.mjs
CHROMIUM_EXECUTABLE_PATH=/tmp/yautja-chromium/chromium DEADWALL_QA_ROOT=/workspace/scratch/b8ff726dd748/deadwall/dist DEADWALL_QA_OUTPUT=/tmp/deadwall-defense148/final DEADWALL_QA_PROFILES=mobile-landscape node scripts/browser-defenses148.mjs
```

Chaque profil produit son propre rapport horodaté. Un seul échec doit rester explicitement visible ; un arrêt ou crash ne valide pas le profil. Les sorties du premier essai partiel restent conservées dans `browser/defenses-2026-10-22T11_06_41_004Z`.

Empreintes attendues après application :

- `scripts/browser-defenses-fixtures148.mjs` : SHA-256 `4ff18a94ae6df9daedca437b39e998c980f1d5023d76cf27b7202c4492baa8e7`.
- `tests/defenses-qa148.test.cjs` : SHA-256 `0bebd9cdf8fd1a42cb169779b1588fd03ac3391b81eca04c39a026b97c9095b7`.

La première preuve est limitée à six tests natifs réussis et aux 86 contrôles desktop terminés avant le crash du renderer ; aucun profil complet n’est encore revendiqué.
