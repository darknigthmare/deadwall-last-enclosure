import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn, execFileSync} from 'node:child_process';
import {captureSource201, sourceStable201} from '/workspace/scratch/b8ff726dd748/deadwall/scripts/full-check201.mjs';

const root='/workspace/scratch/b8ff726dd748/deadwall';
const expected='a137e2f714649083e460fcf25b0d84b7ea1bee57';
const groups={atlas:{script:'scripts/browser-sites162.mjs',runtimeRoot:root,expectedProfiles:2},guide:{script:'scripts/browser-codex-inspection2026.mjs',runtimeRoot:path.join(root,'dist'),expectedProfiles:2}};
const name=process.argv[2], group=groups[name];
assert.ok(group,'Expected atlas or guide');
const output='/tmp/deadwall-restauration-root-browser-20261022/'+name;
assert.ok(!fs.existsSync(output),'Preserve prior evidence by selecting a new run directory');
fs.mkdirSync(output,{recursive:true});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
function walk(directory,prefix=''){
  return fs.readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name)).flatMap(entry=>{
    const relative=path.posix.join(prefix,entry.name), full=path.join(directory,entry.name);
    if(entry.isDirectory())return walk(full,relative);
    if(!entry.isFile())throw new Error('Unexpected non-regular distribution entry '+relative);
    const bytes=fs.readFileSync(full);return [[relative,{bytes:bytes.length,sha256:hash(bytes)}]];
  });
}
function capture(){
  const distribution=Object.fromEntries(walk(path.join(root,'dist')));
  return {source:captureSource201(root),distribution,distributionManifestSha256:hash(JSON.stringify(distribution))};
}
function reports(directory){
  return fs.readdirSync(directory,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?reports(path.join(directory,entry.name)):entry.name==='report.json'?[path.join(directory,entry.name)]:[]);
}
const before=capture();
assert.equal(before.source.head,expected);assert.equal(before.source.clean,true);
fs.writeFileSync(path.join(output,'before.json'),JSON.stringify(before,null,2)+'\n');
const log=fs.openSync(path.join(output,'browser.log'),'wx');
const started=new Date().toISOString(), begin=performance.now();
const env={...process.env,CHROMIUM_EXECUTABLE_PATH:'/tmp/chromium',DEADWALL_QA_OUTPUT:output,DEADWALL_QA_ROOT:group.runtimeRoot};
const result=await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,[group.script],{cwd:root,env,stdio:['ignore',log,log]});
  child.once('error',reject);child.once('exit',(code,signal)=>resolve({code,signal}));
});
fs.closeSync(log);
const after=capture();
fs.writeFileSync(path.join(output,'after.json'),JSON.stringify(after,null,2)+'\n');
const reportFiles=reports(output), parsed=reportFiles.map(file=>({file,report:JSON.parse(fs.readFileSync(file,'utf8'))}));
const receipt={schemaVersion:1,kind:'browser-after-restoration',group:name,command:['node',group.script],expectedHead:expected,sourceTree:before.source.tree,started,finished:new Date().toISOString(),durationSeconds:(performance.now()-begin)/1000,nodeExitCode:result.code,signal:result.signal,browserExecutable:'/tmp/chromium',browserExecutableSha256:hash(fs.readFileSync('/tmp/chromium')),browserVersion:execFileSync('/tmp/chromium',['--version'],{encoding:'utf8'}).trim(),runtimeRoot:group.runtimeRoot,sourceAndDistributionUnchanged:false,accepted:false,reportFiles,profiles:parsed.flatMap(({report})=>report.profiles??[]).map(p=>({name:p.viewport?.name??p.viewport?.width,pass:p.pass??true,checks:p.checks?.length??null,failedChecks:p.checks?.filter(c=>!c.pass).length??null})),scope:name==='atlas'?'Real Atlas controls and prepared author site rendering, served from source; not a default campaign acquisition or Windows certification.':'Guide inspection via author controls on the restored distribution, with default-title absence check and unchanged campaign save material; no new campaign placement.'};
try{
  assert.equal(result.code,0);assert.equal(result.signal,null);
  sourceStable201(before.source,after.source,expected);
  assert.deepEqual(after.distribution,before.distribution);
  receipt.sourceAndDistributionUnchanged=true;
  assert.equal(parsed.length,1);
  assert.equal(parsed[0].report.pass??parsed[0].report.ok,true);
  assert.equal(receipt.profiles.length,group.expectedProfiles);
  assert.ok(receipt.profiles.every(p=>p.pass && (p.failedChecks===null || p.failedChecks===0)));
  if(name==='guide')assert.equal(receipt.profiles.reduce((n,p)=>n+p.checks,0),128);
  receipt.accepted=true;
}catch(error){receipt.failure=error.stack;process.exitCode=1;}
fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt,null,2));
