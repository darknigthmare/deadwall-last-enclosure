const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root='/workspace/scratch/b8ff726dd748/deadwall',out=__dirname;
const sha=buffer=>crypto.createHash('sha256').update(buffer).digest('hex');
const git=(...args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const browser='/tmp/chromium';
const env={...process.env,CHROMIUM_EXECUTABLE_PATH:browser,DEADWALL_QA_OUTPUT:out,DEADWALL_QA_PROFILES:'desktop,mobile,mobile-landscape'};
delete env.DEADWALL_QA_URL;delete env.DEADWALL_QA_ROOT;
const proof={kind:'restored-source-targeted-browser-check',startedAt:new Date().toISOString(),sourceCommit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),statusBefore:git('status','--porcelain'),node:process.version,command:[process.execPath,'scripts/browser-sprites159.mjs'],environment:{CHROMIUM_EXECUTABLE_PATH:browser,DEADWALL_QA_OUTPUT:out,DEADWALL_QA_PROFILES:env.DEADWALL_QA_PROFILES},browserBinary:{path:browser,bytes:fs.statSync(browser).size,sha256:sha(fs.readFileSync(browser))},limitations:['New run on restored bytes. Previously lost local logs are not reused.','Desktop and mobile profiles are browser emulations in the declared legacy author fixture, not physical-device or full-game certification.']};
const receipt=path.join(out,'browser-receipt.json'),log=path.join(out,'sprites-browser.log');
fs.writeFileSync(receipt,JSON.stringify(proof,null,2)+'\n');
const fd=fs.openSync(log,'w'),start=Date.now();
const result=cp.spawnSync(process.execPath,['scripts/browser-sprites159.mjs'],{cwd:root,env,stdio:['ignore',fd,fd]});fs.closeSync(fd);
proof.finishedAt=new Date().toISOString();proof.elapsedMs=Date.now()-start;proof.exitCode=result.status;proof.signal=result.signal;proof.error=result.error?String(result.error):null;proof.statusAfter=git('status','--porcelain');
const logBytes=fs.readFileSync(log);proof.log={path:log,bytes:logBytes.length,sha256:sha(logBytes)};
const reportPaths=fs.readdirSync(out,{withFileTypes:true}).filter(e=>e.isDirectory()&&e.name.startsWith('sprites159-')).map(e=>path.join(out,e.name,'report.json')).filter(p=>fs.existsSync(p));
if(reportPaths.length===1){const reportBytes=fs.readFileSync(reportPaths[0]),report=JSON.parse(reportBytes);proof.report={path:reportPaths[0],bytes:reportBytes.length,sha256:sha(reportBytes)};proof.summary={pass:report.pass,browserVersion:report.browserVersion,profiles:report.profiles.map(p=>({name:p.viewport.name,pass:p.pass,checks:p.checks.length,passed:p.checks.filter(c=>c.pass).length,errors:['pageErrors','consoleErrors','httpErrors','requestFailures'].reduce((n,k)=>n+(p[k]?.length||0),0),commanderBefore:p.contactBody?.playerBefore,commanderAfter:p.contactBody?.playerAfter,unitsBefore:p.contactBody?.contactStates?.before?.units,unitsAfter:p.contactBody?.contactStates?.after?.units,sourceBinding:{observedFiles:p.sourceBinding?.observedFiles,expectedFiles:p.sourceBinding?.expectedFiles,mismatch:p.sourceBinding?.mismatch,missing:p.sourceBinding?.missing}})),changedFiles:report.sourceBinding.changedFiles,runtimeFiles:Object.keys(report.sourceBinding.before).length,qaFiles:Object.keys(report.sourceBinding.qaBefore).length};}
else proof.reportError='Expected one fresh report, found '+reportPaths.length;
fs.writeFileSync(receipt,JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof,null,2));
process.exitCode=result.status===0&&proof.summary?.pass&&proof.summary.profiles.length===3&&proof.summary.profiles.reduce((n,p)=>n+p.passed,0)===159?0:1;
