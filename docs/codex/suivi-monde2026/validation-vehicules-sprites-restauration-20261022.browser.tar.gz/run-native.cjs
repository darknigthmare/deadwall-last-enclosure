const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const root = '/workspace/scratch/b8ff726dd748/deadwall';
const out = __dirname;
const files = ['tests/vehicle-boundary151.test.cjs', 'scripts/browser-sprites-fixtures159.mjs', 'scripts/browser-sprites159.mjs'];
function git(...args) { return cp.execFileSync('git', args, {cwd:root, encoding:'utf8'}).trim(); }
function sources() { return Object.fromEntries(files.map(p => [p, crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')])); }
const proof = {kind:'restored-source-native-targeted-check', startedAt:new Date().toISOString(), sourceCommit:git('rev-parse','HEAD'), statusBefore:git('status','--porcelain'), node:process.version, command:[process.execPath,'--test','tests/vehicle-boundary151.test.cjs'], sourcesBefore:sources(), limitations:['This is a new run on restored source bytes; prior lost logs are not reused.', 'This targeted receipt does not qualify the complete game or browser profiles.']};
const metadata=path.join(out,'native-receipt.json');
fs.writeFileSync(metadata, JSON.stringify(proof,null,2)+'\n');
const log=path.join(out,'vehicle-native.log');
const fd=fs.openSync(log,'w');
const started=Date.now();
const result=cp.spawnSync(process.execPath,['--test','tests/vehicle-boundary151.test.cjs'],{cwd:root,stdio:['ignore',fd,fd],env:process.env});
fs.closeSync(fd);
proof.finishedAt=new Date().toISOString();proof.elapsedMs=Date.now()-started;proof.exitCode=result.status;proof.signal=result.signal;proof.error=result.error?String(result.error):null;
proof.statusAfter=git('status','--porcelain');proof.sourcesAfter=sources();
const body=fs.readFileSync(log,'utf8');proof.log={path:log,bytes:Buffer.byteLength(body),sha256:crypto.createHash('sha256').update(body).digest('hex')};
proof.footer=Object.fromEntries(['tests','suites','pass','fail','cancelled','skipped','todo','duration_ms'].map(key=>{const match=body.match(new RegExp('^# '+key+' (.+)$','m'));return [key,match?Number(match[1]):null];}));
fs.writeFileSync(metadata,JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify(proof,null,2));
process.exitCode=result.status===0&&proof.footer.tests===12&&proof.footer.pass===12&&proof.footer.fail===0?0:1;
