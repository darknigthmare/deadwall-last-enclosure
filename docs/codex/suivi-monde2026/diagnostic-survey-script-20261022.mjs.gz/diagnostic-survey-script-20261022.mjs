import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createHarness, ready} from '/workspace/scratch/b8ff726dd748/deadwall/scripts/browser-qa-common142.mjs';

const repo='/workspace/scratch/b8ff726dd748/deadwall';
const baseCommit='74a62084e96dd7e78463bd4e15b9ec2897887704';
process.env.DEADWALL_QA_OUTPUT='/tmp/deadwall-survey-20261022';
process.env.CHROMIUM_EXECUTABLE_PATH='/tmp/yautja-chromium/chromium';
const sha=value=>createHash('sha256').update(value).digest('hex');
const changes=execFileSync('git',['diff','--name-only',baseCommit,'--','index.html','src','sw.js'],{cwd:repo,encoding:'utf8'}).trim().split('\n').filter(Boolean);
const overrides=new Map();
for(const file of changes){
  try{overrides.set(file,execFileSync('git',['show',baseCommit+':'+file],{cwd:repo,stdio:['ignore','pipe','ignore']}));}catch{/* A new source file is absent from the baseline entry. */}
}
const h=await createHarness('native-survey','Targeted Chromium diagnostic of the native Windows smoke survey fixture, story/rearguard seed17117. Same centre relocation and synchronous .25-second survey calls; genuine pause and command controls. No full campaign, Electron, Windows or packaging qualification. Current source and baseline entry/scripts compared without modifying the repository.');
const {report}=h;
report.surface='Targeted native-survey diagnostic: current default player entry, main74a default player entry, and an explicitly separate legacy author fixture. Each profile records its requested URL and actual source substitutions.';
report.originalHarnessDefaultURL=report.base;report.base=new URL(h.base).origin+'/';
report.baseline=baseCommit;report.current=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();report.profiles=[];
report.baselineOverrides=[...overrides].map(([file,body])=>({file,sha256:sha(body)}));
try{
 for(const kind of ['current-default','baseline-default','current-legacy']){
  const profile={kind,errors:[],httpErrors:[],overrides:[]};report.profiles.push(profile);
  const ctx=await h.browser.newContext({viewport:{width:1280,height:800},serviceWorkers:'block'}),page=await ctx.newPage();
  page.setDefaultTimeout(30000);page.on('pageerror',e=>profile.errors.push(e.message));page.on('response',r=>{if(r.status()>=400)profile.httpErrors.push({status:r.status(),url:r.url()});});
  if(kind==='baseline-default')await page.route('**/*',async route=>{
   const u=new URL(route.request().url()),file=u.pathname==='/'?'index.html':u.pathname.slice(1),body=overrides.get(file);
   if(!body)return route.continue();profile.overrides.push(file);
   return route.fulfill({status:200,body,contentType:file.endsWith('.html')?'text/html; charset=utf-8':'text/javascript; charset=utf-8'});
  });
  try{
   const url=new URL(h.base);if(!kind.endsWith('legacy'))url.search='';profile.requestedURL=url.href;
   await page.goto(url.href,{waitUntil:'networkidle',timeout:120000});await ready(page);
   profile.setup=await page.evaluate(()=>{
    const game=DEADWALL,get=id=>document.getElementById(id);
    const difficulty=document.querySelector('input[name="difficulty"][value="story"]');difficulty.checked=true;difficulty.dispatchEvent(new Event('change',{bubbles:true}));
    get('startScenario').value='rearguard';get('startScenario').dispatchEvent(new Event('change',{bubbles:true}));
    get('mapSeed').value='17117';get('mapSeed').dispatchEvent(new Event('input',{bubbles:true}));
    get('newGameButton').click();if(game.campaignIntro132?.isOpen())get('campaignIntro132Skip').click();
    game.togglePause(true);game.resources.wood=137;game.player.x+=32;
    return{seed:game.world.seed,scenario:game.scenarioId,difficulty:game.difficulty.id,state:game.state,paused:game.paused,generation:game.frontier.snapshot().generation,cityGeometry202:game.world.cityGeometry202,inspection:typeof DeadwallCodexInspection2026,inspectionPanels:document.querySelectorAll('[data-codex-inspection2026]').length};
   });
   profile.commands=await page.evaluate(async()=>{
    const game=DEADWALL,get=id=>document.getElementById(id),elapsed=game.elapsed;
    get('pauseCommandButton').click();await new Promise(r=>setTimeout(r,160));
    get('commandTab-workers').click();document.querySelector('[data-worker-order="retreat"]').click();get('commandTab-research').click();
    const suspended=game.elapsed===elapsed;get('commandTab-records').click();get('commandClose').click();
    game.togglePause(false);get('cityCommandButton').click();get('commandClose').click();game.togglePause(true);
    get('pauseCommandButton').click();get('commandTab-workers').click();
    const panel=get('squadCommandPanel');panel.querySelector('[data-squad-select="0"]').click();panel.querySelector('[data-squad-action="retreat"][data-squad-index="0"]').click();panel.querySelector('[data-squad-select="2"]').click();
    get('commandTab-enclosure').click();game.battlefieldUI.refresh(true);game.battlefieldUI.refreshDefeat();get('commandClose').click();
    return{suspended,paused:game.paused,overlay:game.activeOverlay?.id||null,health:game.player.health,dead:game.player.dead,gameOver:game.gameOver};
   });
   profile.survey=await page.evaluate(()=>{
    const game=DEADWALL,C=DeadwallCore,rules=C.NARRATIVE_RULES,origin={x:game.player.x,y:game.player.y},copy=v=>JSON.parse(JSON.stringify(v));
    const building=b=>b?{id:b.id,type:b.type,x:b.x,y:b.y,tx:b.tx,ty:b.ty,w:b.w,h:b.h,completed:b.completed,dead:b.dead,open:b.open,geometryVersion202:b.geometryVersion202}:null;
    const guards=dt=>{
     const p=game.player,r=p.radius*.78,site=game.world.sites.find(s=>(p.x-s.x)**2+(p.y-s.y)**2<=rules.surveyRadius**2),record=site&&game.narrative.sectors[site.theme];
     const probes=[{x:p.x-r,y:p.y},{x:p.x+r,y:p.y},{x:p.x,y:p.y-r},{x:p.x,y:p.y+r}].map(q=>({...q,building:building(game.world.solidForFriendly(q.x,q.y))}));
     const clear=game.friendlyPositionClear(p,p.x,p.y),reasons=[];
     if(game.state!=='playing')reasons.push('not-playing');if(game.paused)reasons.push('paused');if(game.gameOver)reasons.push('game-over');if(p.dead)reasons.push('player-dead');if(p.health<=0)reasons.push('nonpositive-health');if(!site)reasons.push('no-nearby-site');if(!record)reasons.push('missing-record');if(record?.survey>=rules.surveySeconds)reasons.push('already-complete');if(!clear)reasons.push('obstructed-position');if(!game.input.keys.has('KeyE'))reasons.push('KeyE-absent');if(!Number.isFinite(dt)||dt<=0)reasons.push('invalid-dt');
     return{state:game.state,paused:game.paused,gameOver:game.gameOver,dead:p.dead,health:p.health,position:{x:p.x,y:p.y,radius:p.radius},site:site?{id:site.id,theme:site.theme,name:site.name,x:site.x,y:site.y}:null,survey:record?.survey,KeyE:game.input.keys.has('KeyE'),clear,probes,reasons};
    };
    const before={resources:copy(game.resources),insight:game.research.insight,morale:game.morale};game.togglePause(false);game.input.keys.add('KeyE');
    const runs=[];
    for(const [theme,seconds]of [['market',2],['housing',rules.surveySeconds]]){
     const site=game.world.sites.find(item=>item.theme===theme),run={theme,seconds,attempts:[]};runs.push(run);Object.assign(game.player,{x:site.x,y:site.y});
     for(let elapsed=0;elapsed<seconds;elapsed+=.25){const dt=Math.min(.25,seconds-elapsed),before=guards(dt),advanced=game.updateNarrativeSurvey(dt);run.attempts.push({elapsed,before,advanced,after:game.narrative.sectors[theme].survey});if(!advanced)break;}
    }
    const recovery=[];
    for(const [theme,target]of [['market',2],['housing',rules.surveySeconds]]){
     const site=game.world.sites.find(s=>s.theme===theme),record=game.narrative.sectors[theme];if(record.survey>=target)continue;
     let chosen=null;for(let d=1;d<rules.surveyRadius&&!chosen;d++)for(let i=0;i<32;i++){const a=i*Math.PI/16,q={x:site.x+Math.cos(a)*d,y:site.y+Math.sin(a)*d};if(game.friendlyPositionClear(game.player,q.x,q.y)){chosen={...q,distance:d};break;}}
     const run={theme,chosen,attempts:[]};recovery.push(run);if(!chosen)continue;Object.assign(game.player,{x:chosen.x,y:chosen.y});
     let safety=0;while(record.survey<target&&safety++<40){const dt=Math.min(.25,target-record.survey),before=guards(dt),advanced=game.updateNarrativeSurvey(dt);run.attempts.push({before,advanced,after:record.survey});if(!advanced)break;}
    }
    const after={resources:copy(game.resources),insight:game.research.insight,morale:game.morale};game.input.keys.delete('KeyE');Object.assign(game.player,origin);game.togglePause(true);
    return{rules,runs,recovery,rewardsUnchanged:JSON.stringify(before)===JSON.stringify(after),final:{market:game.narrative.sectors.market,housing:game.narrative.sectors.housing}};
   });
   profile.sourceOverrides=profile.overrides.map(file=>({file,sha256:sha(overrides.get(file)),commit:baseCommit}));
   profile.pass=true;
   console.log(JSON.stringify({kind,setup:profile.setup,commands:profile.commands,runs:profile.survey.runs.map(r=>({theme:r.theme,steps:r.attempts.length,first:r.attempts[0],last:r.attempts.at(-1)})),recovery:profile.survey.recovery.map(r=>({theme:r.theme,chosen:r.chosen,steps:r.attempts.length,last:r.attempts.at(-1)})),errors:profile.errors,httpErrors:profile.httpErrors}));
  }catch(e){profile.pass=false;profile.failure=e.stack;throw e;}
  finally{await ctx.close();}
 }
 report.pass=true;
}finally{await h.finish();await h.close();}
