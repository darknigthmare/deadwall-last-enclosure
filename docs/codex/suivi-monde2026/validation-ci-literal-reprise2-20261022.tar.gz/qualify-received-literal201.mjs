import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { qualifyFullCheck201 } from '/workspace/scratch/b8ff726dd748/deadwall/scripts/full-check201.mjs';

const HEAD = 'a137e2f714649083e460fcf25b0d84b7ea1bee57';
const TREE = '172bf1a43d4c7546853415f5d20c5a2592292252';
const RUN = '39789162646', JOB = '119860245492';
const root = '/workspace/scratch/b8ff726dd748/deadwall';
const directory = path.resolve(process.argv[2]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const receiptBytes = fs.readFileSync(path.join(directory, 'receipt.json'));
const receipt = JSON.parse(receiptBytes);
const log = fs.readFileSync(path.join(directory, 'native.log'));
const result = { verifiedAt: new Date().toISOString(), runId: RUN, jobId: JOB,
  expectedHead: HEAD, expectedTree: TREE, accepted: false,
  receivedClaimedAccepted: receipt.accepted, receivedFailure: receipt.failure ?? null,
  startedAt: receipt.startedAt, completedAt: receipt.completedAt,
  durationMs: Date.parse(receipt.completedAt) - Date.parse(receipt.startedAt),
  receivedCounters: receipt.counts, npmExitCode: receipt.actualExitCode,
  teeExitCode: receipt.teeExitCode, signal: receipt.signal,
  receiptSha256: sha(receiptBytes), logSha256: sha(log), logBytes: log.length,
  validatorSha256: sha(fs.readFileSync(path.join(root, 'scripts/full-check201.mjs'))),
  provenance: 'Independent local qualification of original CI receipt and native.log bytes; no test execution or workflow change.' };
try {
  assert.equal(receipt.expectedHead, HEAD, 'Unexpected CI head');
  assert.equal(receipt.runId, RUN, 'Unexpected CI run');
  assert.equal(receipt.sourceBefore.tree, TREE, 'Unexpected CI tree before execution');
  assert.equal(receipt.sourceAfter.tree, TREE, 'Unexpected CI tree after execution');
  // New fixes may legitimately be prepared in the current worktree while this
  // older CI run finishes. Bind to every immutable Git blob of the requested
  // commit, including original mode, rather than trusting live worktree bytes.
  const objectSource = JSON.parse(execFileSync('python3', [
    '/tmp/deadwall-ci-literal-a137-20261022/source-at-a137.py', root, HEAD, TREE
  ], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }));
  assert.equal(objectSource.head, HEAD); assert.equal(objectSource.tree, TREE);
  assert.deepEqual(objectSource.files, receipt.sourceBefore.files, 'CI inventory differs from exact Git blob bytes or modes');
  assert.deepEqual(objectSource.scripts, receipt.sourceBefore.scripts, 'CI commands differ from committed package');
  const tests = Object.keys(objectSource.files).filter(name => /^tests\/[^/]+\.test\.cjs$/.test(name)).sort();
  assert.deepEqual(tests, receipt.sourceBefore.testFiles, 'CI test inventory differs from committed files');
  for (const name of ['scripts/full-check201.mjs', 'scripts/ci-native-receipt160.mjs']) {
    assert.equal(sha(fs.readFileSync(path.join(root, name))), objectSource.files[name].sha256, 'Local verifier differs from requested commit: ' + name);
  }
  result.gitObjectSourceInventoryMatches = true;
  result.qualification = qualifyFullCheck201(receipt, log);
  result.accepted = result.qualification.accepted;
} catch (error) {
  result.failure = String(error.stack || error);
}
const target = path.join('/tmp/deadwall-ci-literal-a137-20261022', 'independent-qualification.json');
fs.writeFileSync(target, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
if (!result.accepted) process.exitCode = 1;
