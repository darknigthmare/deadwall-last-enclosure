"""Read immutable commit blobs; never trust or modify a working checkout."""
import sys, subprocess, hashlib, json
root, head, expected_tree = sys.argv[1:]
def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=root)
tree = git('rev-parse', head + '^{tree}').decode().strip()
assert tree == expected_tree
entries = []
for item in git('ls-tree', '-rz', '--full-tree', head).split(b'\0'):
    if not item:
        continue
    meta, name = item.split(b'\t', 1)
    mode, kind, blob = meta.decode().split()
    assert kind == 'blob' and mode.startswith('100'), (name, mode, kind)
    entries.append((name.decode(), mode, blob))
batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
files = {}
package = None
try:
    for name, mode, blob in sorted(entries):
        batch.stdin.write((blob + '\n').encode()); batch.stdin.flush()
        received_blob, kind, size = batch.stdout.readline().decode().strip().split()
        assert received_blob == blob and kind == 'blob'
        size = int(size); remaining = size; digest = hashlib.sha256(); parts = []
        while remaining:
            data = batch.stdout.read(min(remaining, 1024 * 1024))
            assert data, 'truncated Git blob'
            digest.update(data); remaining -= len(data)
            if name == 'package.json': parts.append(data)
        assert batch.stdout.read(1) == b'\n'
        files[name] = {'sha256': digest.hexdigest(), 'bytes': size, 'mode': mode}
        if name == 'package.json': package = json.loads(b''.join(parts))
    batch.stdin.close()
    assert batch.wait() == 0
finally:
    if batch.poll() is None: batch.kill(); batch.wait()
assert package is not None
print(json.dumps({'head': head, 'tree': tree, 'files': files, 'scripts': {key: package['scripts'][key] for key in ['check', 'test']}}, ensure_ascii=False, separators=(',', ':')))
