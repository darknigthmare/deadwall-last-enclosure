import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/b8ff726dd748/deadwall')
BASE = Path('/tmp/deadwall-browser-reprise2-recovered-20261022')
SCRIPTS = {
    'reconstruction144': 'scripts/browser-reconstruction144.mjs',
    'products203': 'scripts/browser-products203.mjs',
    'husbandry191': 'scripts/browser-husbandry191.mjs',
    'd17': 'scripts/browser-d17-progression149.mjs',
}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def snapshot():
    tracked = git('ls-files', '--', 'src', 'scripts', 'tests', 'index.html', 'package.json', 'package-lock.json').splitlines()
    source = {name: sha(ROOT / name) for name in tracked}
    dist = {str(p.relative_to(ROOT / 'dist')): sha(p) for p in sorted((ROOT / 'dist').rglob('*')) if p.is_file()}
    return {'time': now(), 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'gitStatus': git('status', '--porcelain'), 'sourceFiles': source, 'distFiles': dist,
            'sourceManifestSHA256': hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'distManifestSHA256': hashlib.sha256(json.dumps(dist, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}

name = sys.argv[1]
script = SCRIPTS[name]
out = BASE / name
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, DEADWALL_QA_ROOT=str(ROOT / 'dist'), DEADWALL_QA_OUTPUT=str(out), CHROMIUM_EXECUTABLE_PATH='/tmp/chromium')
env.pop('DEADWALL_QA_URL', None)
env.pop('DEADWALL_QA_PROFILES', None)
before = snapshot()
(out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
command = ['node', script]
started = now()
start = time.monotonic()
print(json.dumps({'group': name, 'started': started, 'head': before['head'], 'distManifestSHA256': before['distManifestSHA256'], 'output': str(out)}), flush=True)
with (out / 'browser.log').open('w') as log:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line); log.flush(); print(line, end='', flush=True)
    code = process.wait()
after = snapshot()
(out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
unchanged = before['sourceFiles'] == after['sourceFiles'] and before['distFiles'] == after['distFiles']
receipt = {'group': name, 'command': command, 'environment': {k: env[k] for k in ['DEADWALL_QA_ROOT', 'DEADWALL_QA_OUTPUT', 'CHROMIUM_EXECUTABLE_PATH']},
           'started': started, 'finished': now(), 'durationSeconds': time.monotonic() - start, 'nodeExitCode': code,
           'head': before['head'], 'tree': before['tree'], 'sourceAndDistUnchanged': unchanged,
           'before': str(out / 'before.json'), 'after': str(out / 'after.json'), 'log': str(out / 'browser.log'),
           'reports': [str(p) for p in out.glob('*/report.json')],
           'scope': 'New execution after environment recovery on checkpoint a137e2f; prior lost browser receipts were not recreated.'}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(code if code else (0 if unchanged else 91))
