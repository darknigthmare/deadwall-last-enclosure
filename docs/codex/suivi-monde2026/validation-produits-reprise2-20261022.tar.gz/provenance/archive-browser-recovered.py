from pathlib import Path
import gzip
import hashlib
import json
import sys
import tarfile

BASE = Path('/tmp/deadwall-browser-reprise2-recovered-20261022')
OUT = Path('/tmp/deadwall-proofs-reprise2-20261022')
OUT.mkdir(exist_ok=True)
label, *names = sys.argv[1:]
stem = 'validation-' + label + '-reprise2-20261022'
groups = []
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

for name in names:
    base = BASE / name
    receipt = json.loads((base / 'receipt.json').read_text())
    raw_path = Path(receipt['reports'][0])
    report = json.loads(raw_path.read_text())
    before = json.loads((base / 'before.json').read_text())
    after = json.loads((base / 'after.json').read_text())
    profiles = []
    for p in report['profiles']:
        profile = {'viewport': p['viewport'], 'checks': len(p['checks']), 'passedChecks': sum(c['pass'] for c in p['checks']),
                   'errors': {key: len(p[key]) for key in ['pageErrors', 'consoleErrors', 'httpErrors', 'requestFailures']}}
        if 'pass' in p:
            profile['reportedPass'] = p['pass']
        if 'knife' in p:
            profile['knife'] = p['knife']
        if 'storageRebuilding' in p:
            profile['paidWarehouses'] = []
            for entry in p['storageRebuilding']:
                b = entry['building']
                search = b['placementSearch']
                profile['paidWarehouses'].append({'id': b['id'], 'gx': b['gx'], 'gy': b['gy'], 'cost': b['cost'],
                    'resourcesBefore': b['before']['resources'], 'resourcesAfter': b['after']['resources'],
                    'storageBefore': entry['before']['storage'], 'storageAfter': entry['completed']['storage'],
                    'inspections': len(search['inspections']), 'maximumInspections': search['maximumInspections'],
                    'zooms': search['zooms'], 'firstRejections': search['inspections'][0]['rejected'],
                    'lastRejections': search['inspections'][-1]['rejected'],
                    'ordinarySimulationWorkSeconds': b['workRoute']['ordinarySimulationWorkSeconds']})
        profiles.append(profile)
    groups.append({'name': name, 'command': receipt['command'], 'environment': receipt['environment'],
                   'head': receipt['head'], 'tree': receipt['tree'], 'started': receipt['started'], 'finished': receipt['finished'],
                   'durationSeconds': receipt['durationSeconds'], 'exitCode': receipt['nodeExitCode'], 'pass': report['pass'],
                   'browserVersion': report['browserVersion'], 'surface': report['surface'], 'scope': report['scope'],
                   'sourceAndDistUnchanged': receipt['sourceAndDistUnchanged'],
                   'sourceFiles': len(before['sourceFiles']), 'distFiles': len(before['distFiles']),
                   'sourceManifestSHA256': before['sourceManifestSHA256'], 'distManifestSHA256': before['distManifestSHA256'],
                   'gitStatusBefore': before['gitStatus'], 'gitStatusAfter': after['gitStatus'],
                   'reportRelativePath': str(raw_path.relative_to(BASE)), 'rawReportSHA256': sha(raw_path), 'profiles': profiles})

with tarfile.open(OUT / (stem + '.tar.gz'), 'w:gz') as tar:
    for name in names:
        tar.add(BASE / name, arcname=name)
    for producer in ['run-browser-recovered.py', 'archive-browser-recovered.py']:
        tar.add(Path(__file__).parent / producer, arcname='provenance/' + producer)
with gzip.open(OUT / (stem + '.log.gz'), 'wb') as log:
    for name in names:
        log.write(('=== New execution after recovery: ' + name + ' ===\n').encode())
        log.write((BASE / name / 'browser.log').read_bytes())
        log.write(b'\n')
summary = {'schema': 'deadwall-targeted-browser-validation-v1',
           'provenance': 'New execution after environment recovery on source checkpoint a137e2f. Prior lost runtime receipts were not recreated or treated as evidence.',
           'groups': groups,
           'totals': {'profiles': sum(len(g['profiles']) for g in groups),
                      'checks': sum(p['checks'] for g in groups for p in g['profiles']),
                      'passedChecks': sum(p['passedChecks'] for g in groups for p in g['profiles']),
                      'errors': sum(sum(p['errors'].values()) for g in groups for p in g['profiles'])},
           'pass': all(g['pass'] and g['exitCode'] == 0 and g['sourceAndDistUnchanged'] for g in groups),
           'hashConvention': 'SHA256 of sorted compact JSON maps of relative paths to file SHA256; all before/after maps are archived.',
           'limitations': ['Prepared scenario state is explicitly identified in each raw report; no claim of organically earned advanced campaigns or physically tested mobile hardware.',
                           'The paid knife uses native craft/transfer/equip owners with stepped production time; this does not establish DOM interaction with the armory or human elapsed time.',
                           'No lost pre-recovery native test receipt is included in this browser qualification.'],
           'archives': {stem + '.tar.gz': sha(OUT / (stem + '.tar.gz')), stem + '.log.gz': sha(OUT / (stem + '.log.gz'))}}
(OUT / (stem + '.json')).write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'summary': str(OUT / (stem + '.json')), 'pass': summary['pass'], 'totals': summary['totals'], 'archiveBytes': (OUT / (stem + '.tar.gz')).stat().st_size}))
