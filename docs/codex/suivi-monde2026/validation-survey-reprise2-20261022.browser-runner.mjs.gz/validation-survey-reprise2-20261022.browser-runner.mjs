import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHarness, recorder, ready, chooseCampaign, campaignSnapshot, observeRestore, restoredCampaign }
  from '/workspace/scratch/b8ff726dd748/deadwall/scripts/browser-qa-common142.mjs';

// This diagnostic records absolute execution paths. It is not a portable user tool.
const repository='/workspace/scratch/b8ff726dd748/deadwall',dist=path.join(repository,'dist');
const script=fileURLToPath(import.meta.url),sha=data=>createHash('sha256').update(data).digest('hex');
process.env.DEADWALL_QA_ROOT=dist;
process.env.DEADWALL_QA_OUTPUT||='/tmp/deadwall-narrative-reprise2-restored-20261022';
process.env.CHROMIUM_EXECUTABLE_PATH||='/tmp/chromium';
const sourceNames=['index.html','src/core.js','src/game.js','src/fieldcraft.js','src/narrative.js','src/narrative-ui.js',
  'src/content-ui.js','src/fieldcraft-ui.js','src/exploration-125.js','src/world-content.js','desktop/smoke.cjs',
  'tests/narrative-spatial202.test.cjs','scripts/browser-qa-common142.mjs'];
async function inventory(directory,prefix=''){
  const entries=[];
  for(const entry of (await fs.readdir(directory,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    const relative=prefix+entry.name,absolute=path.join(directory,entry.name);
    if(entry.isDirectory())entries.push(...await inventory(absolute,relative+'/'));
    else if(entry.isFile()){const bytes=await fs.readFile(absolute);entries.push({path:relative,bytes:bytes.length,sha256:sha(bytes)});}
  }
  return entries;
}
async function fingerprint(){
  const sources={};for(const name of sourceNames)sources[name]=sha(await fs.readFile(path.join(repository,name)));
  const files=await inventory(dist),manifest=files.map(f=>`${f.path}\t${f.bytes}\t${f.sha256}\n`).join('');
  return {at:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{cwd:repository,encoding:'utf8'}).trim(),
    tree:execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:repository,encoding:'utf8'}).trim(),
    status:execFileSync('git',['status','--porcelain'],{cwd:repository,encoding:'utf8'}),sources,
    dist:{root:dist,count:files.length,bytes:files.reduce((n,f)=>n+f.bytes,0),manifestSha256:sha(manifest),files},
    runner:{path:script,sha256:sha(await fs.readFile(script))}};
}
const before=await fingerprint();
for(const name of sourceNames.filter(name=>name==='index.html'||name.startsWith('src/'))){
  assert.equal(before.dist.files.find(file=>file.path===name)?.sha256,before.sources[name],`Built file must equal current source: ${name}`);
}
const smokeText=await fs.readFile(path.join(repository,'desktop/smoke.cjs'),'utf8');
const startToken='  const narrative = await window.webContents.executeJavaScript(`',endToken='`, true);';
assert.equal(smokeText.split(startToken).length,2,'One exact desktop narrative block');
const start=smokeText.indexOf(startToken)+startToken.length,end=smokeText.indexOf(endToken,start);
assert.ok(end>start);const smokeTemplate=smokeText.slice(start,end);
for(const token of ['${JSON.stringify(stage)}','${JSON.stringify(expectedNarrative)}'])assert.equal(smokeTemplate.split(token).length,2);
const smokeProgram=(stage,expected)=>smokeTemplate.replace('${JSON.stringify(stage)}',JSON.stringify(stage))
  .replace('${JSON.stringify(expectedNarrative)}',JSON.stringify(expected));

const harness=await createHarness('narrative-restored-reprise2-20261022',
  'Fresh Chromium Linux qualification after maintenance on the default current player entry served from rebuilt dist. Profile native-walk walks from the actual spawn via held native Arrow inputs and bounded full Game.update steps, retaining phase time, economy, obstacles and actors; then holds the real browser KeyE under the ordinary RAF for eight active survey seconds. Journal pages, marker, decision, save and Continue use actual DOM controls. Profile exact-desktop-narrative executes the unchanged narrative template extracted from desktop/smoke.cjs, substituting only its two parameters. That explicit integration fixture relocates the commander and steps native survey actions; it is not a travel proof. No Windows/Electron run, physical device, full campaign or performance certification is claimed.');
const {browser,report,output}=harness;
const entry=new URL(harness.base);entry.searchParams.delete('tools');entry.searchParams.delete('fixture');
const base=entry.href;
Object.assign(report,{base,surface:'Default player entry (/), without tools or fixture query; current G10/R4 campaign',
  checkpoint:'a137e2f714649083e460fcf25b0d84b7ea1bee57',provenance:{before},profiles:[],
  execution:{node:process.version,platform:process.platform,chromiumExecutable:process.env.CHROMIUM_EXECUTABLE_PATH,
    cwd:process.cwd(),entryURL:base,servedRoot:dist,serviceWorkers:'block'},
  smokeBlock:{source:'desktop/smoke.cjs',sourceSha256:before.sources['desktop/smoke.cjs'],templateSha256:sha(smokeTemplate),
    substitutions:['stage','expectedNarrative'],unchangedAssertions:true,windowsElectronReplayed:false},
  lostEvidence:'All previous unarchived local reports were deleted by maintenance. This report records only this fresh run.'});
await fs.writeFile(path.join(output,'dist-manifest-before.json'),JSON.stringify(before.dist,null,2)+'\n');
await fs.writeFile(path.join(output,'smoke-block-template.txt'),smokeTemplate);
await fs.copyFile(script,path.join(output,'runner.mjs'));

async function launchCampaign(page){
  await page.goto(base);await ready(page);
  await page.locator('input[name="difficulty"][value="story"]').check();
  await page.locator('#startScenario').selectOption('rearguard');
  await chooseCampaign(page,'17117');
  await page.locator('#campaignIntro132Skip').click();
  await page.waitForFunction(()=>DEADWALL.state==='playing'&&!DEADWALL.paused&&!DEADWALL.activeOverlay&&!DEADWALL.campaignIntro132.isOpen());
  return page.evaluate(()=>({seed:DEADWALL.world.seed,difficulty:DEADWALL.difficulty.id,scenario:DEADWALL.scenarioId,
    cityGeometry202:DEADWALL.world.cityGeometry202,layoutRevision:DEADWALL.exploration125.layoutRevision,
    generation:DEADWALL.frontier.position().generation,player:{x:DEADWALL.player.x,y:DEADWALL.player.y},
    runId:DEADWALL.runId,resources:{...DEADWALL.resources},phase:DEADWALL.phase,phaseTime:DEADWALL.phaseTime,elapsed:DEADWALL.elapsed}));
}
function identity(value){assert.equal(value.seed,17117);assert.equal(value.difficulty,'story');assert.equal(value.scenario,'rearguard');
  assert.equal(value.cityGeometry202,1);assert.equal(value.layoutRevision,4);assert.equal(value.generation,10);}
async function journal(page,theme='market'){
  if(!await page.locator('#pauseMenu').isVisible())await page.locator('#pauseButton').click();
  await page.locator('#pauseCommandButton').click();
  await page.locator('#commandTab-journal').click();
  const card=page.locator(`[data-narrative-sector="${theme}"]`);
  // The real journal paginates its sector cards. Reach the actual visible leaf.
  for(let i=0;i<6&&await page.locator('#journalPrev14').isEnabled();i++)await page.locator('#journalPrev14').click();
  for(let i=0;i<6&&!await card.isVisible();i++)await page.locator('#journalNext14').click();
  assert.equal(await card.isVisible(),true,'Requested journal leaf is visible');
  if(!await card.evaluate(node=>node.open))await card.locator('summary').click();
  return card;
}
async function closeJournal(page){
  await page.locator('#commandClose').click();
  if(await page.locator('#pauseMenu').isVisible())await page.locator('#resumeButton').click();
}
async function walk(page,destination){
  return page.evaluate(destination=>{
    const g=DEADWALL,C=DeadwallCore,origin={x:g.player.x,y:g.player.y},elapsed=g.elapsed,phaseTime=g.phaseTime;
    if(g.paused||g.activeOverlay||g.gameOver||g.player.dead)throw Error('Native walking requires an active campaign');
    const path=C.findFriendlyPath({x:C.grid(origin.x),y:C.grid(origin.y)},
      {x:C.grid(destination.x),y:C.grid(destination.y)},(x,y)=>!g.friendlyPositionClear(g.player,C.world(x),C.world(y)));
    if(!path)throw Error('No native route to the requested point');
    const goals=path.map(cell=>({x:C.world(cell.x),y:C.world(cell.y)}));goals.push(destination);
    const keys=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'];let ticks=0,travel=0,minProgress=Infinity,maxStep=0;
    const set=(x,y)=>{for(const key of keys)g.input.keys.delete(key);if(Math.abs(x)>.1)g.input.keys.add(x>0?'ArrowRight':'ArrowLeft');if(Math.abs(y)>.1)g.input.keys.add(y>0?'ArrowDown':'ArrowUp');};
    try{
      for(const goal of goals){
        while(C.dist(g.player,goal)>.3){
          if(++ticks>6000)throw Error('Bounded native walk exceeded its tick limit');
          const dx=goal.x-g.player.x,dy=goal.y-g.player.y,d=Math.hypot(dx,dy),dt=Math.min(.04,d/400),from={x:g.player.x,y:g.player.y};
          set(dx,dy);g.update(dt);g.input.pressed.clear();
          const moved=C.dist(g.player,from);if(moved<1e-8)throw Error('Actual movement owner did not advance');
          if(!g.friendlyPositionClear(g.player,g.player.x,g.player.y))throw Error('Native movement reached an obstructed position');
          if(g.paused||g.activeOverlay||g.gameOver||g.player.dead)throw Error('Campaign interrupted the native walk');
          travel+=moved;minProgress=Math.min(minProgress,moved);maxStep=Math.max(maxStep,moved);
        }
      }
    }finally{for(const key of keys)g.input.keys.delete(key);g.input.pressed.clear();}
    return {origin,destination,arrival:{x:g.player.x,y:g.player.y},cells:path.length,ticks,travel,minProgress,maxStep,
      elapsedBefore:elapsed,elapsedAfter:g.elapsed,phaseBefore:phaseTime,phaseAfter:g.phaseTime,
      survey:g.narrative.sectors.market.survey,physicallyClear:g.friendlyPositionClear(g.player,g.player.x,g.player.y)};
  },destination);
}
async function saveAndContinue(page){
  if(!await page.locator('#pauseMenu').isVisible())await page.locator('#pauseButton').click();
  await page.locator('#saveButton').click();const checkpoint=await campaignSnapshot(page);
  assert.equal(checkpoint.ok,true);
  await page.reload();await ready(page);await observeRestore(page);await page.locator('#continueButton').click();
  assert.equal(await restoredCampaign(page,checkpoint),true,JSON.stringify(checkpoint.restoreComparison));
  return checkpoint;
}

try{
  for(const name of ['native-walk','exact-desktop-narrative']){
    const profile={name,url:base,httpOverrides:[],viewport:{width:1440,height:900},started:new Date().toISOString()};report.profiles.push(profile);
    const context=await browser.newContext({viewport:profile.viewport,deviceScaleFactor:1,serviceWorkers:'block'});
    const page=await context.newPage(),{check,screenshot,errors}=recorder(page,profile,output,name+'-');
    page.setDefaultTimeout(20000);
    const verify=async(title,fn)=>{try{await fn();check(title);}catch(error){if(!profile.checks.some(item=>item.name===title))profile.checks.push({name:title,pass:false});throw error;}};
    try{
      profile.initial=await launchCampaign(page);
      await verify('Default player entry starts current G10/R4 seed17117 story/rearguard through real controls',async()=>identity(profile.initial));
      if(name==='native-walk'){
        profile.spatial=await page.evaluate(()=>{
          const g=DEADWALL,C=DeadwallCore,E=DeadwallExploration125,site=g.world.sites.find(s=>s.theme==='market'),point=g.narrativeSurveyPoint('market');
          const solid=E.physicalSolids134(g.exploration125.plan).find(s=>s.building==='settlement-2-building-2');
          return {site,point,solid,oldCentreClear:g.friendlyPositionClear(g.player,site.x,site.y),
            pointClear:!!point&&g.friendlyPositionClear(g.player,point.x,point.y),radius:C.NARRATIVE_RULES.surveyRadius,
            offset:point&&C.dist(site,point),survey:g.narrative.sectors.market.survey};
        });
        await verify('The historical market disc is inside its real building and the derived point is physically clear',async()=>{
          const {site,point,solid,radius,oldCentreClear,pointClear,offset,survey}=profile.spatial;
          assert.ok(solid);assert.ok(site.x-radius>solid.x&&site.x+radius<solid.x+solid.w&&site.y-radius>solid.y&&site.y+radius<solid.y+solid.h);
          assert.equal(oldCentreClear,false);assert.equal(pointClear,true);assert.ok(offset>0&&offset<=360);assert.equal(survey,0);assert.ok(point);
        });
        let card=await journal(page);
        await verify('The visible journal marks the shared point without moving or rewarding the commander',async()=>{
          assert.match(await card.innerText(),/point de relevé, cellule 55,91/);
          const read=()=>page.evaluate(()=>({position:{x:DEADWALL.player.x,y:DEADWALL.player.y},resources:{...DEADWALL.resources},
            insight:DEADWALL.research.insight,narrative:JSON.parse(JSON.stringify(DEADWALL.narrative)),random:DEADWALL.random.state}));
          const before=await read();await card.locator('[data-narrative-mark="market"]').click();assert.deepEqual(await read(),before);
          assert.equal(await page.evaluate(()=>DEADWALL.fieldMarker),profile.spatial.site.id);
        });
        await closeJournal(page);
        profile.outward=await walk(page,profile.spatial.point);
        await verify('The actual movement owner reaches the point from spawn with physical steps and ordinary simulation time',async()=>{
          const w=profile.outward;assert.ok(w.ticks>0&&w.travel>0&&w.minProgress>0);assert.equal(w.physicallyClear,true);
          assert.ok(w.elapsedAfter>w.elapsedBefore);assert.ok(w.phaseAfter<w.phaseBefore);assert.equal(w.survey,0);
          assert.ok(Math.hypot(w.arrival.x-w.destination.x,w.arrival.y-w.destination.y)<=.3);
        });
        await page.locator('#game').focus();
        const surveyStart=await page.evaluate(()=>({elapsed:DEADWALL.elapsed,survey:DEADWALL.narrative.sectors.market.survey,insight:DEADWALL.research.insight}));
        const heldAt=Date.now();await page.keyboard.down('e');
        try{await page.waitForFunction(()=>DEADWALL.narrative.sectors.market.survey===DeadwallCore.NARRATIVE_RULES.surveySeconds,null,{timeout:60000});}
        finally{await page.keyboard.up('e');}
        profile.survey={wallMs:Date.now()-heldAt,before:surveyStart,after:await page.evaluate(()=>({elapsed:DEADWALL.elapsed,
          survey:DEADWALL.narrative.sectors.market.survey,insight:DEADWALL.research.insight,choice:DEADWALL.narrative.sectors.market.choice,
          position:{x:DEADWALL.player.x,y:DEADWALL.player.y},clear:DEADWALL.friendlyPositionClear(DEADWALL.player,DEADWALL.player.x,DEADWALL.player.y)}))};
        await verify('Real browser KeyE under ordinary RAF completes eight active seconds without a free decision or insight',async()=>{
          const s=profile.survey;assert.equal(s.before.survey,0);assert.equal(s.after.survey,8);assert.ok(s.wallMs>=7900);
          assert.ok(s.after.elapsed-s.before.elapsed>=7.99);assert.equal(s.after.insight,s.before.insight);assert.equal(s.after.choice,null);assert.equal(s.after.clear,true);
        });
        card=await journal(page);
        await verify('A completed remote survey still refuses the paid decision until the real return to the depot',async()=>{
          assert.equal(await card.locator('[data-narrative-choice="A"]').isDisabled(),true);
          assert.match(await card.locator('.narrative-reason').innerText(),/Retournez près du centre de commandement/);
          assert.equal(await card.locator('progress').getAttribute('max'),'8');
        });
        await screenshot('market-releve');await closeJournal(page);
        const depot=await page.evaluate(()=>DEADWALL.fieldcraft.service(DEADWALL.player,DEADWALL.core()));assert.ok(depot);
        profile.inward=await walk(page,depot);
        await verify('The commander physically walks back to the native depot access',async()=>{
          assert.ok(profile.inward.ticks>0&&profile.inward.travel>0);assert.equal(profile.inward.physicallyClear,true);
          assert.equal(await page.evaluate(()=>DEADWALL.workerCanWorkAt(DEADWALL.player,DEADWALL.core(),DeadwallCore.NARRATIVE_RULES.debriefRadius)),true);
        });
        card=await journal(page);
        await verify('The visible journal pays the exact existing cost once and persists the resolved choice',async()=>{
          const before=await page.evaluate(()=>({resources:{...DEADWALL.resources},insight:DEADWALL.research.insight,
            option:DeadwallNarrative.SECTORS.find(s=>s.id==='market').choices.A}));
          const button=card.locator('[data-narrative-choice="A"]');assert.equal(await button.isEnabled(),true);await button.click();
          const after=await page.evaluate(()=>({resources:{...DEADWALL.resources},insight:DEADWALL.research.insight,choice:DEADWALL.narrative.sectors.market.choice}));
          for(const key of Object.keys(before.resources))assert.equal(after.resources[key],before.resources[key]-(before.option.cost[key]||0));
          assert.equal(after.insight,before.insight+1);assert.equal(after.choice,'A');assert.equal(await button.isDisabled(),true);
          profile.decision={before,after};
        });
        await screenshot('decision-paid');await closeJournal(page);
        await verify('Real Save/reload/Continue conserves the normalized campaign including RNG, stocks and narrative',async()=>{
          profile.checkpoint=await saveAndContinue(page);assert.equal(profile.checkpoint.restoreComparison.pass,true);
          assert.deepEqual(await page.evaluate(()=>DEADWALL.narrativeSurveyPoint('market')),profile.spatial.point);
        });
        await verify('No page, console, HTTP or request errors',async()=>assert.equal(errors(),0));
      }else{
        await verify('The executed desktop narrative template is extracted verbatim; only the original two parameters are substituted',async()=>{
          assert.equal(sha(await fs.readFile(path.join(repository,'desktop/smoke.cjs'))),report.smokeBlock.sourceSha256);
          assert.equal(smokeTemplate.includes("throw new Error('Native survey action did not advance')"),true);
          assert.equal(smokeProgram('create',null).includes('${JSON.stringify('),false);
        });
        await page.locator('#pauseButton').click();
        await verify('The exact native smoke create block retains market2s, housing8s, paid choice, read and repeat assertions',async()=>{
          profile.create=await page.evaluate(smokeProgram('create',null));
          const result=profile.create;assert.equal(result.partialSurvey,2);assert.equal(result.state.sectors.housing.survey,8);
          assert.equal(result.choice,'A');assert.equal(result.repeatRejected,true);assert.equal(result.read,true);
          assert.equal(result.surveyPoints.length,2);assert.ok(result.surveyPoints.every(p=>p.point));
        });
        const expected={state:profile.create.state,insight:profile.create.insight};
        await verify('Real Save/reload/Continue preserves the smoke campaign with partial survey and unique housing choice',async()=>{
          profile.checkpoint=await saveAndContinue(page);assert.equal(profile.checkpoint.restoreComparison.pass,true);
        });
        if(!await page.locator('#pauseMenu').isVisible())await page.locator('#pauseButton').click();
        await verify('The exact native smoke restore block passes every original narrative assertion',async()=>{
          profile.restore=await page.evaluate(smokeProgram('restore',expected));
          assert.equal(profile.restore.restored,true);assert.deepEqual(profile.restore.state,expected.state);
          assert.equal(profile.restore.insight,expected.insight);assert.equal(profile.restore.repeatRejected,true);
        });
        await screenshot('smoke-restored');
        await verify('No page, console, HTTP or request errors',async()=>assert.equal(errors(),0));
      }
      profile.pass=true;
    }catch(error){profile.pass=false;profile.failure=error.stack;await screenshot('failure').catch(()=>{});}
    finally{await context.close();profile.completed=new Date().toISOString();}
    profile.summary={checks:profile.checks.length,passed:profile.checks.filter(c=>c.pass).length,failed:profile.checks.filter(c=>!c.pass).length,
      errors:profile.pageErrors.length+profile.consoleErrors.length+profile.httpErrors.length+profile.requestFailures.length};
    profile.pass=profile.pass&&profile.summary.errors===0;
    console.log(JSON.stringify({profile:name,pass:profile.pass,...profile.summary,failure:profile.failure?.split('\n')[0]}));
  }
}finally{
  try{await harness.close();}
  finally{
    const after=await fingerprint();report.provenance.after=after;
    report.provenance.stable=JSON.stringify(before.sources)===JSON.stringify(after.sources)&&before.dist.manifestSha256===after.dist.manifestSha256&&before.runner.sha256===after.runner.sha256;
    await fs.writeFile(path.join(output,'dist-manifest-after.json'),JSON.stringify(after.dist,null,2)+'\n');
    report.checks={total:report.profiles.reduce((n,p)=>n+p.checks.length,0),passed:report.profiles.reduce((n,p)=>n+p.checks.filter(c=>c.pass).length,0),
      failed:report.profiles.reduce((n,p)=>n+p.checks.filter(c=>!c.pass).length,0)};
    report.pass=report.profiles.length===2&&report.profiles.every(p=>p.pass)&&report.checks.total===16&&report.checks.failed===0&&report.provenance.stable;
    await harness.finish();
  }
}
if(!report.pass)process.exitCode=1;
